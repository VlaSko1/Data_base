-- Практическое задание по теме “Операторы, фильтрация, сортировка и ограничение”

-- 1. Пусть в таблице users поля created_at и updated_at оказались незаполненными. Заполните их текущими датой и временем.
-- Сначало создадим эти поля:
use vk;
alter table users add created_at datetime, add updated_at datetime;

-- заполняем столбцы created_at и updated_at текущей датой и временем:
update users set created_at=now(), updated_at=now();


-- 2. Таблица users была неудачно спроектирована. Записи created_at и updated_at были заданы типом VARCHAR и в них долгое время помещались значения в формате "20.10.2017 8:10". 
-- Необходимо преобразовать поля к типу DATETIME, сохранив введеные ранее значения.

-- Очистим столбцы created_at и updated_at, изменим их тип и запишем в них выражение '20.10.2017 8:10'

update users set created_at=null, updated_at=null;
ALTER TABLE `users` CHANGE `created_at` `created_at` VARCHAR(40);
ALTER TABLE `users` CHANGE `updated_at` `updated_at` VARCHAR(40);
update users set created_at = '20.10.2017 8:10', updated_at = '20.10.2017 8:10';

-- Создаем две новые колонки created_at_new, updated_at_new с типом данных DATETIME
alter table users add column created_at_new datetime null after created_at;
alter table users add column updated_at_new datetime null after updated_at;

-- Наполняем эти колонки преобразованными данными из соответствующих колонок created_at и updated_at:
update users set created_at_new=date_format(str_to_date(created_at, '%e.%c.%Y %H:%m'), '%Y-%m-%d %H:%m:%s');
update users set updated_at_new=date_format(str_to_date(updated_at, '%e.%c.%Y %H:%m'), '%Y-%m-%d %H:%m:%s');

-- удаляем колонки created_at и updated_at:
alter table users drop created_at, drop updated_at;

-- переименуем колонки created_at_new и updated_at_new в колонки с именами created_at и updated_at:
alter table users change column created_at_new created_at datetime default now();  
alter table users change column updated_at_new updated_at datetime default current_timestamp on update current_timestamp;


-- 3. В таблице складских запасов storehouses_products в поле value могут встречаться самые разные цифры: 0, 
-- если товар закончился и выше нуля, если на складе имеются запасы. 
-- Необходимо отсортировать записи таким образом, чтобы они выводились в порядке увеличения значения value. 
-- Однако, нулевые запасы должны выводиться в конце, после всех записей.

-- Создадим таблицу складских запасов
drop table if exists storehouses_products;
CREATE TABLE `storehouses_products` (
  `id` SERIAL primary key,
  `name` varchar(150) unique NOT NULL,
  `value` int(10) unsigned NOT NULL,
  KEY `value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `storehouses_products` VALUES ('1','et','31'),
('2','deserunt','29'),
('3','delectus','23'),
('4','eligendi','24'),
('5','a','37'),
('6','pariatur','11'),
('7','veniam','10'),
('8','sed','19'),
('9','quod','33'),
('10','autem','19'),
('11','nesciunt','12'),
('12','inventore','48'),
('13','dolore','21'),
('14','distinctio','49'),
('15','temporibus','50'),
('16','quisquam','2'),
('17','perferendis','43'),
('18','enim','9'),
('19','sunt','18'),
('20','atque','29'),
('21','modi','17'),
('22','eos','39'),
('23','ut','37'),
('24','sit','21'),
('25','rerum','21'),
('26','est','24'),
('27','aut','11'),
('28','facilis','5'),
('29','dolor','4'),
('30','cum','9'),
('31','occaecati','16'),
('32','nobis','0'),
('33','qui','14'),
('34','id','33'),
('35','perspiciatis','0'),
('36','quidem','3'),
('37','magnam','17'),
('38','aliquid','0'),
('39','sint','24'),
('40','illum','41'),
('41','maxime','48'),
('42','cumque','18'),
('43','culpa','19'),
('44','tenetur','6'),
('45','nulla','25'),
('46','facere','14'),
('47','excepturi','31'),
('48','expedita','4'),
('49','iste','21'),
('50','quam','38'),
('51','officiis','22'),
('52','rem','32'),
('53','repellendus','45'),
('54','reiciendis','19'),
('55','quae','14'),
('56','blanditiis','45'),
('57','velit','49'),
('58','similique','1'),
('59','nihil','22'),
('60','labore','34'),
('61','molestias','9'),
('62','reprehenderit','45'),
('63','ipsam','16'),
('64','sequi','28'),
('65','molestiae','9'),
('66','numquam','25'),
('67','animi','18'),
('68','consequatur','10'),
('69','quia','18'),
('70','illo','10'),
('71','itaque','6'),
('72','necessitatibus','2'),
('73','cupiditate','38'),
('74','ea','9'),
('75','totam','40'),
('76','ullam','10'),
('77','odio','30'),
('78','placeat','1'),
('79','ducimus','43'),
('80','recusandae','35'),
('81','voluptatem','35'),
('82','fugiat','28'),
('83','dolorem','15'),
('84','dolores','41'),
('85','nisi','14'),
('86','aperiam','45'),
('87','accusamus','39'),
('88','in','13'),
('89','tempora','37'),
('90','quis','3'),
('91','nemo','8'),
('92','eius','31'),
('93','voluptatum','34'),
('94','voluptas','11'),
('95','maiores','28'),
('96','doloremque','22'),
('97','vel','40'),
('98','minima','2'),
('99','voluptate','16'),
('100','laudantium','16'); 

select * from storehouses_products order by if(value = 0, 1, 0) , value;




-- Агрегация данных
-- 1. Подсчитайте средний возраст пользователей в таблице users

select ROUND(AVG(TIMESTAMPDIFF(YEAR, birthday, now()))) as middle_age from profiles;


-- 2.Подсчитайте количество дней рождения, которые приходятся на каждый из дней недели.
-- Следует учесть, что необходимы дни недели текущего года, а не года рождения.

select weekday(str_to_date(concat(date_format(birthday, '%d.%m'), '.', year(now())), '%e.%c.%Y')) as `birthday_day`,
count(birthday) as count from profiles group by birthday_day order by birthday_day;
